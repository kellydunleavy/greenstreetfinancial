import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { Router, ActivatedRoute } from '@angular/router';
import {RoutesService } from "../routes.service";
import { Watchlist } from "../watchlist";
import { StockComponent } from "../stock/stock.component";
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.component.css']
})
export class WatchlistComponent implements OnInit {
  userID: string;
  update_userID: string;
  symbol: string;
  pattern_type: string;
  user_note: string;
  // watch: any;
  watchlist: Observable<Watchlist[]>;
  submitted = false;
  show = true;
  add = true;
  constructor(private route: ActivatedRoute, private routesService: RoutesService,
    private router: Router) { }

  ngOnInit() {
  }

  reloadData() {
    // this.userID = this.route.snapshot.params['userID'];
    // this.routesService.getWatchlist(this.userID).subscribe(data => data.filter((data) => data.userID == this.userID)[0]);
    // this.watchlist = this.routesService.getWatchlist(this.userID).pipe(filter((data) => data.userID == this.userID));
    // console.log(this.watchlist);
    this.routesService.getWatchlist(this.userID)
      .subscribe(data => {
        console.log(data)
        this.watchlist = data;
      }, error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.show = false;
    this.reloadData();    
  }

  update() {
    // this.routesService.getWatchlist(this.userID)
    //   .subscribe(data => {
    //     console.log(data)
    //     this.watch = data;
    //   }, error => console.log(error));
    
    this.routesService.updateWatchlist(this.userID, this.symbol, this.pattern_type, this.user_note)
      .subscribe(data => {
        console.log(data)
        // this.watch = data;
      }, error => console.log(error)); 
  }

  add_form(){
    this.add = false;
  }

  stockDetails(symbol: string){
    this.router.navigate(['stock', symbol]);
  }
}
