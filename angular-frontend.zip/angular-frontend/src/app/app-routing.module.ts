import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StockComponent } from './stock/stock.component';
import { DipBuyComponent } from './dip-buy/dip-buy.component';
import { DipRipComponent } from './dip-rip/dip-rip.component';
import { WatchlistComponent } from './watchlist/watchlist.component';
import { SearchComponent } from './search/search.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent},
  { path: 'diprip', component: DipRipComponent },
  { path: 'dipbuy', component: DipBuyComponent },
  { path: 'stock/:symbol', component: StockComponent },
  { path: 'watchlist', component: WatchlistComponent},
  { path: 'search', component: SearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }