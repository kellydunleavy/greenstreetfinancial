export class Stock {
    symbol: string;
    current_price: number;
    value_change: number;
    percent_change: number;
    previous_close: number;
    open: number;
    volume: number;
    bid_size: number;
    bid_price: number;
    ask_size: number;
    ask_price: number;
    day_high: number;
    day_low: number;
    sentiment_rating: number;
}