import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DipBuy } from './dip-buy';

@Injectable({
  providedIn: 'root'
})
export class RoutesService {
  private baseUrl = 'https://cors-anywhere.herokuapp.com/http://sumuksr2.web.illinois.edu/greenstreetfinancial';
  // http://sumuksr2.web.illinois.edu/greenstreetfinancial?password=c@$hM0n3y1999&type=get_stock_info&symbol='DPW'
  private password = 'c@$hM0n3y1999';
  private quote = '\'';

  constructor(private http: HttpClient) { }

  getStock(symbol: string): Observable<any> {
    
    return this.http.get(`${this.baseUrl}?password=${this.password}&type=get_stock_info&symbol=${this.quote}${symbol}${this.quote}`);
  }

  getDipBuy(): Observable<any> {
    return this.http.get(`${this.baseUrl}?password=${this.password}&type=get_dip_buy_list`);
  }

  getDipRip(): Observable<any> {
    return this.http.get(`${this.baseUrl}?password=${this.password}&type=get_dip_rip_list`);
  }

  getWatchlist(userID: string): Observable<any> {
    // http://sumuksr2.web.illinois.edu/greenstreetfinancial?password=<PASSWORD>&type=mongo_find&collection=watchlist&userID=demo
    return this.http.get(`${this.baseUrl}?password=${this.password}&type=mongo_find&collection=watchlist&userID=${userID}`);
    // return this.http.get(`${this.baseUrl}?password=${this.password}&type=get_watchlist&userID=${this.quote}${userID}${this.quote}`);
  }

  insertWatchlist(userID: string, symbol: string, pattern_type: string, user_note: string): Observable<any> {
    // http://sumuksr2.web.illinois.edu/greenstreetfinancial?password=<PASSWORD>&type=mongo_insert&collection=watchlist&userID=demo&symbol=AAPL&pattern_type=DIPRIP&user_note=Hi I like this one.
    return this.http.get(`${this.baseUrl}?password=${this.password}&type=mongo_insert&collection=watchlist&userID=${userID}&symbol=${symbol}&pattern_type=${pattern_type}&user_note=${user_note}`);
  }

  updateWatchlist(userID: string, symbol: string, pattern_type: string, user_note: string): Observable<any>{
    // http://sumuksr2.web.illinois.edu/greenstreetfinancial?password=<PASSWORD>&type=mongo_update&collection=watchlist&userID=demo&symbol=AAPL&pattern_type=DIPRIP&user_note=Updated User Note LOL.
    return this.http.get(`${this.baseUrl}?password=${this.password}&type=mongo_update&collection=watchlist&userID=${userID}&symbol=${symbol}&pattern_type=${pattern_type}&user_note=${user_note}`);
  }

  deleteWatchlist(){
    return this.http.get(``);
  }

  getSearch(current_price: number, volume: number, sentiment_rating: number): Observable<any> {
    // return this.http.get(`https://cors-anywhere.herokuapp.com/http://sumuksr2.web.illinois.edu/greenstreetfinancial?password=c@$hM0n3y1999&type=advanced_filter&current_price=1.28&volume=10000&sentiment_rating=0.5`);
    return this.http.get(`${this.baseUrl}?password=${this.password}&type=advanced_filter&current_price=${current_price}&volume=${volume}&sentiment_rating=${sentiment_rating}`);
  }
  // getDipBuy(): import("rxjs").Observable<import("./dip-buy").DipBuy[]> {
  //   throw new Error('Method not implemented.');
  // }
  // getDipRip(): import("rxjs").Observable<import("./dip-rip").DipRip[]> {
  //   throw new Error('Method not implemented.');
  // }

}