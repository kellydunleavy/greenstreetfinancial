export class Watchlist {
    symbol: string;
    userID: string;
    pattern_type: string;
    user_note: string;
}