import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { Router } from '@angular/router';
import {RoutesService } from "../routes.service";
import { DipRip } from "../dip-rip";
import { StockComponent } from "../stock/stock.component";

@Component({
  selector: 'app-dip-rip',
  templateUrl: './dip-rip.component.html',
  styleUrls: ['./dip-rip.component.css']
})
export class DipRipComponent implements OnInit {
  add= true;
  userID: string;
  symbol: string;
  user_note: string;
  
  dipRips: Observable<DipRip[]>;

  constructor(private routesService: RoutesService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.dipRips = this.routesService.getDipRip();
  }

  stockDetails(symbol: string){
    this.router.navigate(['stock', symbol]);
  }

  insert(){
    this.routesService.insertWatchlist(this.userID, this.symbol, "DIPRIP", this.user_note)
      .subscribe(data => {
        console.log(data)
        // this.watchlist = data;
      }, error => console.log(error));
  }

  add_form(){
    this.add = false;
  }
}
