import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DipRipComponent } from './dip-rip.component';

describe('DipRipComponent', () => {
  let component: DipRipComponent;
  let fixture: ComponentFixture<DipRipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DipRipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DipRipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
