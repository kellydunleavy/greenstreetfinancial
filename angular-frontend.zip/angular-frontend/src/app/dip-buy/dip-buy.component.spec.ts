import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DipBuyComponent } from './dip-buy.component';

describe('DipBuyComponent', () => {
  let component: DipBuyComponent;
  let fixture: ComponentFixture<DipBuyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DipBuyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DipBuyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
