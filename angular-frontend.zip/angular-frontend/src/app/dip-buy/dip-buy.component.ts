import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { Router } from '@angular/router';
import {RoutesService } from "../routes.service";
import { DipBuy } from "../dip-buy";
import { StockComponent } from "../stock/stock.component";

@Component({
  selector: 'app-dip-buy',
  templateUrl: './dip-buy.component.html',
  styleUrls: ['./dip-buy.component.css']
})
export class DipBuyComponent implements OnInit {
  add= true;
  userID: string;
  symbol: string;
  user_note: string;
  
  dipBuys: Observable<DipBuy[]>;

  constructor(private routesService: RoutesService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.dipBuys = this.routesService.getDipBuy();
  }

  stockDetails(symbol: string){
    this.router.navigate(['stock', symbol]);
  }

  insert(){
    this.routesService.insertWatchlist(this.userID, this.symbol, "DIPBUY", this.user_note)
      .subscribe(data => {
        console.log(data)
        // this.watchlist = data;
      }, error => console.log(error));
  }

  add_form(){
    this.add = false;
  }
}
