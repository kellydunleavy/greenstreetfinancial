export class DipRip {
    symbol: string;
    price: number;
    volume_traded: number;
    percent_change: number;
    threshold: number;
}