import { Component, OnInit, Input } from '@angular/core';
import { Observable } from "rxjs";
import { Router, ActivatedRoute } from '@angular/router';
import { Stock } from '../stock';
import { RoutesService } from '../routes.service';
import { Location } from '@angular/common';
// import { DipBuyComponent } from '../dip-buy/dip-buy.component';
// import { DipRipComponent } from '../dip-rip/dip-rip.component';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent implements OnInit {
  symbol: string;
  stock: Stock;

  constructor(private route: ActivatedRoute, private router: Router,
    private routesService: RoutesService, private location: Location) { }

  ngOnInit() {
    this.reloadData();

  }

  reloadData(){
    this.stock = new Stock();
    this.symbol = this.route.snapshot.params['symbol'];

    this.routesService.getStock(this.symbol)
      .subscribe(data => {
        console.log(data)
        this.stock = data;
      }, error => console.log(error));
  }

  back() {
    this.location.back();
  }

}
