export class DipBuy {
    symbol: string;
    bid_ask_ratio: number;
    volume_change: number;
    price_drop: number;
}