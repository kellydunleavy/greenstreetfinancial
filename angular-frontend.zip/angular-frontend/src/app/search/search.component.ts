import { Component, OnInit } from '@angular/core';
import { Stock } from '../stock';
import { Observable } from "rxjs";
import { Router } from '@angular/router';
import {RoutesService } from "../routes.service";
import { DipRip } from "../dip-rip";
import { StockComponent } from "../stock/stock.component";

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  result: Observable<any>;
  submitted = false;
  show = true;
  current_price: number;
  volume: number;
  sentiment_rating: number;

  constructor(private routesService: RoutesService,
    private router: Router) { }

  ngOnInit() {
  }

  save() {
    this.routesService
    .getSearch(this.current_price, this.volume, this.sentiment_rating).subscribe(data => {
      console.log(data)
      this.result = data;
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.show = false;
    this.save();    
  }

}